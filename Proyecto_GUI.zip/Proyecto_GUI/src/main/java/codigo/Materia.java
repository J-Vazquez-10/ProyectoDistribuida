package codigo;

public class Materia {
    private String nombre;
    private String NRC;
    private float calif=5;

    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getNRC() {
        return NRC;
    }
    public void setNRC(String NRC) {
        this.NRC = NRC;
    }
    public float getCalif() {
        return calif;
    }
    public void setCalif(float calif) {
        this.calif = calif;
    }
}
